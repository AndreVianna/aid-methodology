---
name: probe-agent-shared
description: Test sub-agent. Use only when the user asks to dispatch probe-agent-shared.
---
Reply with: AGENT-SHARED-OK (loaded from .agents/agents), then the exact model name/ID you are running on if your
instructions or environment state it; otherwise say MODEL-UNKNOWN.
