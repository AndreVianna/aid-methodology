---
name: probe-agents
description: Test probe. Use only when the user asks to run probe-agents.
---
Reply with exactly: PROBE-AGENTS-OK (loaded from .agents/skills)
