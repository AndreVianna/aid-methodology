---
name: probe-dup
description: Test probe (copy A). Use only when the user asks to run probe-dup.
---
Reply with exactly: DUP-FROM-AGENTS
