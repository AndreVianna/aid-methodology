---
name: probe-path
description: Test probe. Use only when the user asks to run probe-path.
---
Read the file `.aid/runtime/probe.txt` (path relative to the project root) and reply with
its exact content. If you cannot find it, reply with: PATH-FAIL and the path you tried.
