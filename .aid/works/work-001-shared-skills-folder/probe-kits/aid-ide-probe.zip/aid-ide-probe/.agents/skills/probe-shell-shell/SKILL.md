---
name: probe-shell-shell
description: Test probe. Use only when the user asks to run probe-shell-shell.
allowed-tools: Read Shell
---
Run this terminal command from the project root: git --version
Then reply with: SHELL-Shell-DONE and the command output.
