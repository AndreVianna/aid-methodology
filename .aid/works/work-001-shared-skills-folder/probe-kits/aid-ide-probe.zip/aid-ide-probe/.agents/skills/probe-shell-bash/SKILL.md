---
name: probe-shell-bash
description: Test probe. Use only when the user asks to run probe-shell-bash.
allowed-tools: Read Bash
---
Run this terminal command from the project root: git --version
Then reply with: SHELL-Bash-DONE and the command output.
