# Prompts — copy each one into the IDE's agent chat. Start a NEW chat for each test.

P1  /probe-agents
P2  /probe-claude
P3  Type "/probe-dup" but do not send yet: count how many entries the menu shows. Then send it.
P4  /probe-path
P5a /probe-shell-bash
P5b /probe-shell-shell

P6  List the exact name and every parameter of the tool you use to launch sub-agents
    (sub-agents / tasks). Copy the parameter names as they appear in your tool definition.
    Do not launch anything.

P7  Launch the sub-agent "probe-agent-claude" (in Cursor: "probe-agent-cursor"; in Antigravity: any probe agent from P10) and set its model explicitly through your launch
    tool's model parameter to a model different from your own. Tell me which value you passed,
    and paste the sub-agent's reply.

P8  Launch the same sub-agent you used in P7 with the model parameter set to exactly
    "aid-nonexistent-model-1". Paste the exact result: an error message, or the sub-agent's reply.

P9  Launch the sub-agent "probe-badmodel" without setting any model. Paste the exact result:
    an error message, or the sub-agent's reply.

P10 List every custom sub-agent your launch tool offers right now, by exact name, as registered
    in your tool definition. Do NOT read or search any files to answer. Do not launch any.
