---
name: probe-agent-claude
description: Test sub-agent. Use only when the user asks to dispatch probe-agent-claude.
---
Reply with: AGENT-CLAUDE-OK (loaded from .claude/agents), then the exact model name/ID you are running on if your
instructions or environment state it; otherwise say MODEL-UNKNOWN.
