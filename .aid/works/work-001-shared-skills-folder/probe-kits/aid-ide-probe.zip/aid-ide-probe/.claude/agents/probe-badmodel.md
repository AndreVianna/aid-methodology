---
name: probe-badmodel
description: Test sub-agent with a fake model. Use only when the user asks to dispatch probe-badmodel.
model: aid-nonexistent-model-1
---
Reply with: PROBE-BADMODEL-RAN, then the exact model name/ID you are running on if your
instructions or environment state it; otherwise say MODEL-UNKNOWN.
