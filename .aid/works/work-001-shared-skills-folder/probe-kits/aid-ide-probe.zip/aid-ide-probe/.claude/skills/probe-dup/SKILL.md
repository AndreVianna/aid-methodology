---
name: probe-dup
description: Test probe (copy B). Use only when the user asks to run probe-dup.
---
Reply with exactly: DUP-FROM-CLAUDE
