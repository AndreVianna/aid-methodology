---
name: probe-claude
description: Test probe. Use only when the user asks to run probe-claude.
---
Reply with exactly: PROBE-CLAUDE-OK (loaded from .claude/skills)
