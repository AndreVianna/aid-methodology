---
name: probe-agent-cursor
description: Test sub-agent. Use only when the user asks to dispatch probe-agent-cursor.
---
Reply with: AGENT-CURSOR-OK (loaded from .cursor/agents), then the exact model name/ID you are running on if your
instructions or environment state it; otherwise say MODEL-UNKNOWN.
