# AID IDE probe — results

Fill one cell per test and tool. Paste the exact reply, or write what you saw.

| # | Test | Claude Code | Cursor | Antigravity |
|---|------|-------------|--------|-------------|
| 1 | `probe-agents` (in .agents/skills) |  |  |  |
| 2 | `probe-claude` (in .claude/skills) |  |  |  |
| 3a | `probe-dup` shows how many times in the `/` menu? |  |  |  |
| 3b | `probe-dup` reply (which copy won?) |  |  |  |
| 4 | `probe-path` reply |  |  |  |
| 5a | `probe-shell-bash`: permission prompt? (yes/no) |  |  |  |
| 5b | `probe-shell-shell`: permission prompt? (yes/no) |  |  |  |
| 6 | Dispatch-tool parameters (reply to prompt P6) |  |  |  |
| 7 | Dispatch `probe-agent` with a chosen model (reply to P7) |  |  |  |
| 8 | Dispatch with fake model ID (reply to P8) |  |  |  |
| 9 | Dispatch `probe-badmodel` (reply to P9) |  |  |  |
| 10 | Sub-agents listed (which of: probe-agent-claude / -cursor / -shared / -antigravity) |  |  |  |
