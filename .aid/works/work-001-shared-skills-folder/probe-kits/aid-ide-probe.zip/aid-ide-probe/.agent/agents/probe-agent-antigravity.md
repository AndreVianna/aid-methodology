---
name: probe-agent-antigravity
description: Test sub-agent. Use only when the user asks to dispatch probe-agent-antigravity.
---
Reply with: AGENT-ANTIGRAVITY-OK (loaded from .agent/agents), then the exact model name/ID you are running on if your
instructions or environment state it; otherwise say MODEL-UNKNOWN.
