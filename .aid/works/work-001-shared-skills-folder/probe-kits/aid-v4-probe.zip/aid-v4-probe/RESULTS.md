# AID v4 probe results (pass / fail / unknown -- unknown is never a pass)

| Check | Claude Code | Codex | Cursor | Antigravity | Copilot CLI |
|---|---|---|---|---|---|
| P1 token without reading files |  |  |  |  |  |
| P2 ends with `-- AID RULES LOADED` |  |  |  |  |  |
| P3 token (may read files) |  |  |  |  |  |
| S1a /aid-config loads, no frontmatter error |  |  |  |  |  |
| S1b /aid-config runs, prints settings |  |  |  |  |  |
| S1c shell pre-approved, default mode (Claude Code only) |  | n/a | n/a | n/a | n/a |

A-6 passes for a tool when P1 or P2 shows the rules applied. P3 alone means the agent only reads
the rules on demand.
A-4 passes for a tool when S1a and S1b pass (and S1c for Claude Code).
