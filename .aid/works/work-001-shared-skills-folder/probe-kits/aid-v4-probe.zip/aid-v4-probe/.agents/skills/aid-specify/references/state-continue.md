# State: CONTINUE

The work `STATE.yml`'s `features:` entry for this feature shows `state: In Discussion`; find the first `Pending` or `In Discussion` technical section for this feature and resume **The Loop** for that section.

Emit pipeline phase (silent state-write only — no output, no gate):
```
bash .aid/runtime/scripts/execute/writeback-state.sh --pipeline --field Lifecycle --value Running
bash .aid/runtime/scripts/execute/writeback-state.sh --pipeline --field Phase --value Specify
bash .aid/runtime/scripts/execute/writeback-state.sh --pipeline --field "Active Skill" --value aid-specify
bash .aid/runtime/scripts/execute/writeback-state.sh --pipeline --field Updated --value "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
```

---

## The Loop — Per Section

### 1. Propose

Read relevant KB and codebase for this section. Then:

```
### {Section Name}

Based on {KB evidence}, here's what I propose:

{Concrete technical proposal — specific files, classes, patterns from the codebase.
Reference conventions from coding-standards.md. Fit architecture.md. Use domain terms.
If changing something that exists, call it out.}

What do you think?
```

Update this feature's `sections[]` entry to `state: In Discussion` in the work
`STATE.yml`'s `features:` sequence.

**Proposal quality rules:**
- Reference specific files, classes, patterns from the codebase
- Follow conventions from `coding-standards.md`
- Fit the architecture from `architecture.md`
- Use domain terms from `domain-glossary.md`
- Call out explicitly if changing something that exists
- **Known issues:** If codebase exploration reveals new issues in code this feature
  touches, register them in `.aid/works/{work}/known-issues.md` before proposing.
  Check existing entries first to avoid duplicates. Check `tech-debt.md` — if already
  catalogued there, reference it: `See tech-debt.md #TD-NNN`.

### 2. Discuss

Free-form conversation. The user may:
- **Agree** → move to Write
- **Adjust** → revise proposal, present again
- **Redirect** → different approach. Adapt.
- **Ask questions** → answer from KB/codebase. If you don't know, say so.
- **Raise concerns** → discuss trade-offs with options and pros/cons

Continue until the user is satisfied.

### 3. Write

When agreed:

1. Write the section into `REQUIREMENTS.md § 11 / Feature NNN` under `#### Technical
   Specification`, following `.aid/runtime/templates/specs/technical-specification-template.md`
   — which defines the body's shape (Data Model, Feature Flow, Layers & Components, and
   the conditional sections) and its heading levels, already nested for § 11.
2. Update work `STATE.yml` `features` entry status → `Written`
3. **KB Seeding (greenfield):** If the decision fills a gap in an empty KB doc,
   update that KB doc + INDEX.md + README.md. Log which KB docs were seeded.

### 4. Review

**Agent:** Dispatch with `subagent_type: aid-reviewer` (overriding the default `aid-architect`) **at Large tier** — the executor is the Large `aid-architect`, so reviewer tier >= executor tier (`.aid/runtime/templates/agent-dispatch-tiering.md`). The aid-reviewer must run with clean context — it grades against KB/codebase reality without seeing the aid-architect's working notes. Print before dispatch: `[Review] Dispatching aid-reviewer for SPEC validation.`

▶ aid-reviewer starting (~1–2 min)

Immediately after writing, verify what was written:

- Does it contradict other completed sections in this SPEC?
- Does it align with KB reality (architecture, coding standards, existing patterns)?
- Does it reference real codebase artifacts (not hallucinated paths/classes)?
- Is it concrete enough for implementation (no vague "appropriate pattern" language)?
✓ aid-reviewer done (record actual time) — or ✗ aid-reviewer failed: {reason}

**Grade the section** using the universal rubric (`../../../aid/templates/grading-rubric.md`).
Classify each issue by severity (Minor/Low/Medium/High/Critical). The grade is
calculated — worst issue dominates. Compare to minimum grade from `bash .aid/runtime/scripts/config/read-setting.sh --skill specify --key minimum_grade --default A`.

| Condition | Action |
|-----------|--------|
| Grade ≥ minimum | Mark the section `Complete` in this feature's `features:` entry (work STATE.yml). Next section. |
| Grade < minimum, fixable | Back to Propose with findings. |
| Grade < minimum, systemic | Loopback (KB/Requirements issue). |

```
✅ Data Model section — 2 minor issues (cosmetic naming) → Grade: A.
   Meets minimum B+. Moving to Feature Flow.
```

or:

```
⚠️ Data Model section has an issue: the index strategy contradicts what's
in coding-standards.md §3.2 (composite indices discouraged). Let me re-propose...
```

### Continue or Finish

- More Pending sections → Propose next one (step 1)
- All sections Complete:
  - Set this feature's `state: Ready` in the work `STATE.yml`'s `features:` sequence
  - Print summary with all completed sections
  - `/aid-specify` on this feature now enters **REVIEW** (step 4 on all sections)

**Advance:** **CHAIN** → [State: REVIEW] when all sections are Complete (continue inline).
