# State: PACKAGING

Release artifacts are produced, release notes generated, KB updates routed, and statuses updated.

### Step 4: Package

Follow what infrastructure.md § Deployment prescribes. This step varies by project type.

**The agent adapts to what the KB says. Examples:**
- **PR-based:** Create pull request with structured description
- **Container:** Build image, tag with version, push to registry
- **Package/Library:** Build package, publish to registry (npm, NuGet, Maven, PyPI)
- **Installer:** Build installer (MSIX, DMG, deb), sign if configured
- **Static site:** Build, deploy to CDN/hosting
- **Multiple outputs:** Some projects produce more than one — follow KB

Record what was produced in the package file (Deployment section).

If the project type isn't clear from KB → ask the user, route answer to `.aid/knowledge/STATE.md` `## Q&A (Pending)`.

**PR description format (when applicable):**
```markdown
## Release: {version}

### Deliveries
- delivery-NNN: {name} ({task count} tasks)

### Verification
- Build: ✅
- Tests: ✅ {count} pass ({new} new)
- Lint: ✅

### Changes
- Files changed: {count}
- Lines: +{add} / -{del}
```

### Step 5: Release Notes

Generate release notes in the package file (Release Notes section):

```markdown
## What's New
{For each delivery: one paragraph summarizing user-visible changes}

## Technical Changes
{Significant architecture/infrastructure changes, if any}

## Known Issues
{From known-issues.md — anything deferred or unresolved}
```

### Step 6: KB Updates

Check if implementation revealed anything that should update the Knowledge Base:
- New conventions → flag for coding-standards.md
- Architecture changes → flag for architecture.md
- New integrations → flag for integration-map.md
- Tech debt created or resolved → flag for tech-debt.md
- Data schema changes → flag for schemas.md
- Deployment process changes → flag for infrastructure.md

For each KB update needed:
→ Write a Q&A entry to `.aid/knowledge/STATE.md` `## Q&A (Pending)`
→ The next aid-discover run will process these
- New features shipped → add to feature-inventory.md (route through `.aid/knowledge/STATE.md` Q&A with category: Features)

⚠️ Do NOT directly edit KB docs from deploy — route through Discovery.

### Step 7: Update Statuses

- Package file → Status: Shipped, add date
- Each included delivery in PLAN.md → add `Shipped in: package-NNN` and date
- Per-task `state` (STATE.yml) for included tasks → Status: Shipped
- Work `STATE.yml`'s Deploy State (`deploy` key) → Status: Done, Active Package: —
- Work `STATE.yml`'s Deploy State History → add entry with package name, date, delivery count

### Step 8: Ticket Suggestion (conditional)

If a catalogued `issue-tracker` connector exists in `.aid/connectors/` → print a suggestion:
consider updating tickets for shipped tasks via `/aid-update-ticket status` (mark Done/Closed).
Optional, user-initiated, never auto-invoked; silent (no output) if no issue-tracker connector
is catalogued.

### Step 9: Summary

Print what was done:
```
📦 package-NNN: {version}
   Deliveries: {count} ({list})
   Tasks: {total count}
   Verification: ✅ Build + Tests + Lint
   Output: {what was produced}
   Package file: .aid/works/{work}/packages/package-NNN-{slug}.md
   KB updates: {count} Q&A entries routed to .aid/knowledge/STATE.md
```

**Advance:** **CHAIN** → [State: DONE] (see `references/state-done.md`).
