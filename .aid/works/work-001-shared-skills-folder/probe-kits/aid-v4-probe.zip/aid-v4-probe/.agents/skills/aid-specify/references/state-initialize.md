# State: INITIALIZE

First run for this feature; load context, determine sections, and begin The Loop.

### Step 1: Load Full Context

Read ALL before making any proposal:

1. **The feature's section** — `REQUIREMENTS.md § 11 / Feature NNN`: its Description,
   User Stories, the `§5 FR-N` ids it implements and the `§9 AC-N` ids it owns.
2. **The REQUIREMENTS.md SLICE this feature traces to, not the whole document.** Load
   only the `§5` and `§9` entries the feature section cites by id. A per-feature gate
   that loads the whole of a large requirements document re-reads it once per feature
   per cycle, which is the single worst line in the review budget.

   The slice is derived from those citations rather than a hand-maintained map, so a
   feature citing no requirement surfaces as a defect instead of silently yielding an
   empty slice. The citations ARE the slice key, which is why a § 11 section cites
   `AC-N` ids rather than copying criterion text: a copy would have to be re-read to
   be trusted, and could disagree with § 9 — defeating the point of slicing to it.
3. **KB via INDEX.md** — Read `.aid/knowledge/INDEX.md` first. Use the summaries
   to decide which KB docs are relevant to this feature, then load them.
   At minimum you'll need architecture, coding-standards, and schemas for
   most features, but let the INDEX guide you — don't guess.
   - Check `feature-inventory.md` to understand existing features and how the
     new feature relates to them.
   - **Greenfield:** If KB docs are init placeholders (`❌ Pending`), treat as empty.
     Propose from scratch; decisions will seed KB during Write step.
4. **Codebase** — `Grep`/`Glob` to explore relevant source code. Skip for greenfield.
5. **Known Issues** — Read `.aid/works/{work}/known-issues.md` if it exists. Check `tech-debt.md` in KB.

**During codebase exploration, register known issues** in `.aid/works/{work}/known-issues.md`
(create from `../../../aid/templates/known-issues.md` if missing). Only register issues in code
that this feature touches. See [Known Issues Scope](known-issues-scope.md#known-issues-scope) for criteria.

### Step 2: Determine Applicable Sections

**Core sections (always present unless truly N/A):**

| Section | Content |
|---------|---------|
| Data Model | Tables, columns, types, constraints, FKs, indices — or "no schema changes" |
| Feature Flow | Technical flowchart: request → service → repo → response |
| Layers & Components | What goes in each layer, dependencies, DI registrations |

**Conditional sections — activation rules:**

Each has two paths: **Auto-activate** (obvious from context) or **Ask** (use default question).

| Section | Auto-activate when... | Default question |
|---------|----------------------|------------------|
| API Contracts | KB/Requirements mention endpoints/API | Does this feature expose or modify any APIs? |
| UI Specs | Requirements mention screens/UI or architecture.md documents frontend patterns | Does this feature include UI changes? |
| Events & Messaging | KB has queues/events or async | Does this feature involve async processing or events? |
| DDD Analysis | KB/Requirements indicate DDD | Does the project follow DDD? Define bounded contexts? |
| BDD Scenarios | Requirements indicate BDD/Gherkin | Does the project use BDD? Write Gherkin scenarios? |
| CQRS Specs | KB shows CQRS pattern | Does this feature use Command/Query separation? |
| State Machines | Requirements describe stateful workflows | Any stateful workflows with defined transitions? |
| Security Specs | Requirements mention auth/roles | Specific auth/permission requirements beyond basic? |
| Migration Plan | Brownfield + schema changes | Does this change existing schemas or require migration? |
| Cache Strategy | Requirements mention performance | Performance requirements that may need caching? |
| External Integrations | Requirements mention 3rd party | Does this integrate with external services? |
| Batch/Jobs | Requirements mention scheduled work | Any scheduled jobs or background tasks? |
| Mobile Specs | Requirements target mobile or architecture.md shows mobile targets | Mobile platforms? Offline-first? Platform-specific? |
| Search/Indexing | Requirements mention search | Full-text search or complex filtering needed? |
| AI Enhancements | Requirements mention AI/ML | AI or ML involved? (prompts, RAG, agents, fine-tuning) |
| Telemetry & Tracking | Not obvious | Specific logging, auditing, or alerting requirements? |
| Recovery Management | Not obvious | Disaster recovery or backup requirements? |
| Cloud Support | Requirements mention deploy/cloud | Specific cloud provider requirements? |
| Hardware Requirements | Not obvious | Particular hardware considerations? |

**Conditional section content guide (when activated):**

**UI Specs** — Reference `architecture.md` (and any project-specific repo-presentation docs) for existing UI patterns:
- Component Breakdown: new/modified components, props, state, composition within existing tree
- State Management: local vs global state changes, stores affected, server state sync
- Navigation Changes: new routes, guard changes, deep link additions
- Responsive Behavior: breakpoint-specific layouts, mobile-first decisions
- Design Integration: tokens used, theme changes, design system components extended
- Accessibility: ARIA patterns for new components, keyboard nav, screen reader support

**Mobile Specs** — Reference `architecture.md` for platform context:
- Platform Differences: iOS vs Android behavior for this feature
- Offline Behavior: what works offline, sync strategy, conflict resolution
- Push Notifications: if this feature triggers or handles notifications
- Native APIs: camera, GPS, biometrics, storage, permissions required
- App Store Impact: new permissions, review guideline considerations

### Step 3: Register in work STATE.yml

In the work's `.aid/works/{work}/STATE.yml`, update the `features:` sequence:
- Find the entry whose `id` is this feature's number (`/aid-define` created it at
  decomposition); add one only if it is genuinely absent
- Set `state: In Discussion` and `started` to today
- Entry keys: `id` | `name` | `state` | `grade` | `qa_count` | `started` | `updated` |
  `sections` | `notes` (`work-state-template.yml` declares the shape and the
  `state` enum). Ids are never reused or renumbered — a withdrawn feature keeps
  its entry with `withdrawn: true`.

Emit pipeline phase (silent state-write only — no output, no gate):
```
bash .aid/runtime/scripts/execute/writeback-state.sh --pipeline --field Lifecycle --value Running
bash .aid/runtime/scripts/execute/writeback-state.sh --pipeline --field Phase --value Specify
bash .aid/runtime/scripts/execute/writeback-state.sh --pipeline --field "Active Skill" --value aid-specify
bash .aid/runtime/scripts/execute/writeback-state.sh --pipeline --field Updated --value "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
```

### Step 3b: Connector awareness — record this feature's `ticket_ref` (optional)

If this feature's requirements trace to, or the user names, an already-filed ticket in a
catalogued issue-tracker connector, fetch it by invoking `/aid-read-ticket
[<connector>:]<ticket-id>` — the connector resolution and host-MCP fetch live there (feature-001);
no direct-fetch recipe is re-implemented here — and record a `**Ticket:** <stem>:<external-id>`
line in this feature's section of `REQUIREMENTS.md §11`. Skip silently when no such ticket
applies or no matching connector is catalogued; the delegated read is non-destructive, so no extra
confirm is added.

### Step 4: Present and Start

Present activated sections + ambiguous questions:

```
I've analyzed {feature} against the KB and codebase.

**Core sections:**
- Data Model — {brief rationale}
- Feature Flow — {brief rationale}
- Layers & Components — {brief rationale}

**Also activated:**
- {Section} — {why}

**Questions:**
1. {default question for ambiguous section}
2. ...

Does this look right? Answer the questions, and tell me if I'm missing anything.
```

Process response → update this feature's `features:` entry in the work STATE.yml → begin **The Loop** for first Pending section.

**Advance:** **CHAIN** → [State: CONTINUE] (continue inline).
