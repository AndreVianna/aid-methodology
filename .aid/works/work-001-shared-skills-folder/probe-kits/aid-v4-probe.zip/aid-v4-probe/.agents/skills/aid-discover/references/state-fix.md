# State: FIX

FIX applies Q&A answers and reviewer feedback to bring KB documents up to minimum grade; it is selected when the grade is below minimum and no Pending Q&A entries remain.

### Step 0: Load Pending Findings from Ledger

Read `{{LEDGER}}`. Filter rows where Status ∈ {`Pending`, `Recurred`} — these are the findings to address. If the file does not exist, there is nothing to fix (advance to REVIEW).

**Do NOT modify the ledger during FIX.** The fixer addresses issues; the aid-reviewer agent confirms resolution and updates Status. This separation is the reviewer-ledger contract.

### Step 0b: Partition Findings by KB File (Parallel-FIX prep)

Partition the Pending+Recurred rows by the `Doc` column. The output is a map `{file: [row numbers + descriptions]}` — every finding belongs to exactly one file. Each file's bucket holds its entire finding list.

**Why partition?** FIX dispatches **one sub-agent per affected file**, all in parallel. Each agent owns its file exclusively (single-writer per file is the parallelism-safety invariant). The orchestrator only serializes at the commit/push boundary (Step 4).

### Step 1: Identify Documents Below Threshold

From the partitioned ledger rows (Step 0b), list affected documents ordered by worst severity.
Prioritize: [CRITICAL] → [HIGH] → [MEDIUM].
Print: `[Fix] {N} documents with Pending/Recurred findings. Dispatching {N} sub-agents in parallel...`

### Step 2: Dispatch Parallel FIX Agents (one per affected file)

**Single message, multiple `Agent` tool calls** — all agents run concurrently. For each file with findings:

- **Subagent type**: `aid-tech-writer` for narrative KB docs; `aid-researcher` if depth investigation is needed.
- **Prompt contents**:
  1. The file path being edited.
  2. The file's COMPLETE finding list (severity-tagged, source-tagged).
  3. Any Answered Q&A entries from `STATE.md ## Q&A` that this file should incorporate.
  4. Pointer to relevant source files for verification.
  5. **Manual-edits directive** — the agent MUST use the `Edit` tool to apply targeted changes one-by-one. **NO regex scripts.** Scripts generalize and produce new defects:
     - Replace historical-narrative values (e.g. cycle-log entries)
     - Mangle section headers via context-bleed in regex matches
     - Embed authoring annotations (`(line cite stripped...)`) into user-facing prose
     - Miss inline-narrative variants the anchor didn't anticipate
  6. **Commit-stage only** directive — the agent leaves changes unstaged or staged-but-not-committed. The orchestrator owns the final `git commit` + `git push` step.

- **L2+L3 trace per agent** — each agent gets its own pre-created heartbeat file `.aid/.heartbeat/fix-{agent-type}-{file-slug}-{ts}.txt` and three SEPARATE `Bash(..., run_in_background=true)` timer dispatches per the Dispatch Protocol above.

Print before dispatch:
```
[Fix] Dispatching {N} parallel FIX agents:
  ▶ aid-tech-writer (file: architecture.md, ~{ETA}, heartbeat: ...) starting
  ▶ aid-tech-writer (file: module-map.md, ~{ETA}, heartbeat: ...) starting
  ...
```

**Feature Inventory Generation:** if Features Q&A is in the answered set, the file-agent for `feature-inventory.md` should cross-reference pipeline-contracts.md, module-map.md, domain-glossary.md, schemas.md while editing.

### Step 3: Wait for ALL Parallel Agents

Do NOT proceed to Step 4 until every dispatched agent has reported completion. For each completion, surface `✓ aid-tech-writer (file: X) done in {actual}` and append a calibration row.

### Step 4: Aggregate, Verify, Commit (Sequential — single writer)

After ALL parallel agents return:
1. **Do NOT modify the ledger** — that is the next aid-reviewer agent's job. Issues stay Pending until the aid-reviewer agent verifies and updates Status.
2. Update `**Applied to:**` for each incorporated Q&A answer in `STATE.md ## Q&A`.
3. **Regenerate all registered generated files (per principles.md P3 — auto-gen-last).** Read `.aid/runtime/templates/generated-files.txt`. For each non-comment line, parse `output-path|build-command` and execute the build command. This ensures `metrics.md`, `INDEX.md`, `project-index.md` (and any future registered builders) reflect the FINAL post-fix state of the KB:
   ```bash
   while IFS='|' read -r out_path build_cmd; do
     case "$out_path" in ''|\#*) continue ;; esac
     out_path="${out_path#"${out_path%%[![:space:]]*}"}"
     out_path="${out_path%"${out_path##*[![:space:]]}"}"
     echo "[Fix] Regenerating $out_path ..."
     eval "$build_cmd" || echo "[Fix] WARNING: build failed for $out_path"
   done < .aid/runtime/templates/generated-files.txt
   ```
4. Confirm each registered generated file now exists on disk:
   ```bash
   missing=0
   while IFS='|' read -r out_path _; do
     case "$out_path" in ''|\#*) continue ;; esac
     out_path="${out_path#"${out_path%%[![:space:]]*}"}"
     out_path="${out_path%"${out_path##*[![:space:]]}"}"
     if [[ ! -f "$out_path" ]]; then
       echo "[Fix] WARNING: $out_path missing after regenerate (Step 3 build command failed)"
       missing=$((missing + 1))
     fi
   done < .aid/runtime/templates/generated-files.txt
   [[ $missing -eq 0 ]] || echo "[Fix] $missing generated file(s) missing — investigate before commit"
   ```
   (Semantic re-verification of KB docs against source happens in REVIEW state, not here.)
5. Run any smoke tests relevant to changes.
6. Single `git commit` listing which files each agent touched + the regenerated outputs in `.aid/generated/`.
7. `git push`.

Print: `[Fix] Improving {document}... {old grade} → {new grade}` for each.

### Step 5: Verify Meta-Documents (MANDATORY after every fix pass)

After ALL primary fixes, verify and update in order:
1. **`.aid/knowledge/STATE.md` Q&A** — resolved questions? new unknowns?
2. **INDEX.md** — summaries still match?
3. **README.md** — completeness table still accurate?
4. **AGENTS.md** — build commands, conventions, architecture stale?

Print: `[Fix] Verifying 4 meta-documents...`

### Step 6: Re-Review (MANDATORY — Do NOT Self-Evaluate)

**Dispatch aid-reviewer again.** The fixer CANNOT evaluate its own work.

Print: `[Fix 2/3] Re-reviewing after fixes...`

Read `references/reviewer-prompt.md` for the full prompt. Before dispatch, read `references/document-expectations.md` and substitute its full contents for
the `{{DOCUMENT_EXPECTATIONS}}` placeholder in the appended `reviewer-prompt.md` body — identical
to REVIEW Step 1. This guarantees the FIX-mode re-review sub-agent evaluates against the canonical
expectations even though it cannot resolve the file path on its own. Same contamination prevention rules as REVIEW mode.

▶ aid-reviewer starting (~2–3 min)
Wait for completion.
✓ aid-reviewer done (record actual time) — or ✗ aid-reviewer failed: {reason}

### Step 7: Post-Fix Update

Read new `.aid/knowledge/STATE.md`. Verify Review History preserved (append, not replace under `## Review History`).

Print: `[Fix 3/3] Complete. Grade: {old} → {new}. Run /aid-discover again to {fix remaining issues|proceed}.`

Print: `[State: FIX] complete.`

**Advance:** **CHAIN** → [State: REVIEW] if grade < minimum (rerun review); **CHAIN** → [State: APPROVAL] if grade ≥ minimum. Both continue inline.
