# State: REVIEW

All sections complete; re-review entire spec against current KB and codebase.

The spec was completed previously (the work `STATE.yml`'s `features:` entry has `state: Ready`).

**Ask first:** _"This feature spec is marked Ready. Do you want to reopen it for review?
Is there something specific you want to re-examine?"_

If user confirms → set feature status to `In Discussion`, continue below.
If user has a specific concern → record it as context for the review.

Re-run enters **the same loop at step 4** —
reviewing all sections against current reality.

### Load Current Context

Same as INITIALIZE Step 1: this feature's section of REQUIREMENTS.md § 11, plus the
REQUIREMENTS.md **slice** it traces to (the `§5`/`§9` entries its section cites by id,
never the whole document), KB docs, codebase.

### Review All Sections

For each technical section of this feature, run step 4 of the loop against current state:

1. **KB drift** — SPEC references KB content that changed?
2. **Requirements drift** — Requirements changed since spec was written?
3. **Codebase drift** — Code changed (renamed, refactored by another feature)?
4. **Missing sections** — New conditional sections should now be activated?
5. **Stale content** — Section contradicts what now exists?

### Dispatch the Reviewer

Render `references/reviewer-brief.md` with:
- `{{ARTIFACTS}}` = `REQUIREMENTS.md` + the `§11 / Feature NNN` subsection under review, naming the technical sections in scope (or "the whole feature section")
- `{{CONTEXT}}` = `REQUIREMENTS.md §11 / Feature NNN in work-NNN-{name}. Every section of this feature's `features:` entry is Complete in the work STATE.yml. This is the final review pass before the feature is marked Ready.`

Include in the brief file (not in the dispatch prompt — `reviewer-dispatch.md` § Dispatch by path):
- **Ledger lifecycle:** "Read `.aid/.temp/review-pending/specify-<feature>.md` if it
  exists. For each existing row: verify on disk, update Status (Pending→Fixed if
  resolved; Fixed→Recurred if regressed). Append new findings with Status: Pending."
- **Schema reference:** "Output per `.aid/runtime/templates/reviewer-ledger-schema.md`.
  The ledger is the entire file — ONE markdown table, no headers, no narrative."

Dispatch the `aid-reviewer` subagent **at Large tier** (the executor is the Large
`aid-architect`; reviewer tier >= executor tier per
`.aid/runtime/templates/agent-dispatch-tiering.md`) with a pointer to the rendered brief file
(`reviewer-dispatch.md` § Dispatch by path).

### Grade Overall

After the aid-reviewer returns, run grade.sh on the ledger:

```bash
bash .aid/runtime/scripts/grade.sh --explain .aid/.temp/review-pending/specify-<feature>.md
```

Compare to minimum grade from `bash .aid/runtime/scripts/config/read-setting.sh --skill specify --key minimum_grade --default A`.

| Condition | Action |
|-----------|--------|
| Grade ≥ minimum | Print summary, done. Set this feature's `state: Ready` and its `grade` in the work `STATE.yml`'s `features:` sequence. |
| Grade < minimum, fixable sections | List findings, re-enter loop for affected sections. |
| Grade < minimum, core assumptions wrong | Recommend `--reset`. |

<!-- A delivery-definition review step once sat here and is retired, for two independent
     reasons either of which is sufficient.

     First, a delivery definition is a `### delivery-NNN` stanza in PLAN.md; there is no
     per-delivery file.

     Second, and this held even before that: `/aid-specify` runs BEFORE any delivery exists
     (Specify precedes Plan -- SKILL.md states it in as many words). There is no delivery for a
     feature to refine at this point in the pipeline, so the step could never have run. It
     instructed a review of an artifact that cannot exist yet.

     The ledger discipline it carried is not lost -- it is the same discipline the feature
     review above already applies, on that review's own scope. -->

```
Reviewing {work}/{feature} against current KB and codebase...

Issues found: 1 [LOW] (stale DB column ref), 3 [MINOR] (naming) → **Grade: B+**
Minimum: B+. ✅ Meets minimum.
```

For grades below minimum: re-enter the loop (Propose → Discuss → Write → Review)
for affected sections. When all resolved, set status back to Ready.

**Advance:** **CHAIN** → [State: DONE] when spec is Ready and meets minimum grade (continue inline).
