<!-- AID:BEGIN -->
@AGENTS.md
@.aid/runtime/rules.md
<!-- AID:END -->
