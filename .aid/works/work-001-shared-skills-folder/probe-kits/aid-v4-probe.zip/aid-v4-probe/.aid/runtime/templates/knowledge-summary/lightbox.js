/* ============================================================================
 * lightbox.js -- Theme toggle, click-to-expand lightbox,
 *                breadcrumb scrollspy, and full a11y (focus trap, skip link).
 *
 * Used by /aid-summarize. Inline this file inside a <script> block.
 * Self-contained (no external deps, no runtime diagram engine).
 * ========================================================================== */
(function() {
	'use strict';

	const root = document.documentElement;

	/* ---------- Theme handling ---------- */
	let stored = null;
	try { stored = localStorage.getItem('aid-dashboard-theme'); } catch (e) {}
	const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
	const initialTheme = stored || (prefersDark ? 'dark' : 'light');
	root.setAttribute('data-theme', initialTheme);

	function updateThemeUI(theme) {
		const icon = document.getElementById('theme-icon');
		const label = document.getElementById('theme-label');
		const btn = document.getElementById('theme-toggle');
		if (icon) icon.textContent = theme === 'dark' ? '☀' : '◐';
		if (label) label.textContent = theme === 'dark' ? 'Light' : 'Dark';
		if (btn) btn.setAttribute('aria-label',
			theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
	}
	updateThemeUI(initialTheme);

	function setTheme(theme) {
		root.setAttribute('data-theme', theme);
		try { localStorage.setItem('aid-dashboard-theme', theme); } catch (e) {}
		updateThemeUI(theme);
	}

	/* ---------- Lightbox state ---------- */
	const lb = {
		root: null, stage: null, inner: null, caption: null,
		scale: 1, tx: 0, ty: 0,
		dragging: false, dragStartX: 0, dragStartY: 0, dragOriginX: 0, dragOriginY: 0,
		lastFocused: null
	};

	function lbApplyTransform() {
		if (!lb.inner) return;
		lb.inner.style.transform = 'translate(' + lb.tx + 'px, ' + lb.ty + 'px) scale(' + lb.scale + ')';
	}

	function lbOpen(svg, captionText) {
		if (!lb.root || !svg) return;
		lb.lastFocused = document.activeElement;

		const clone = svg.cloneNode(true);
		/* Inline SVGs may have a constrained max-width. Clear it so the
		   clone can expand to fill the lightbox wrapper, which carries the chrome. */
		clone.style.maxWidth = 'none';
		clone.style.maxHeight = 'none';
		clone.style.width = '100%';
		clone.style.height = '100%';
		clone.removeAttribute('width');
		clone.removeAttribute('height');
		if (!clone.getAttribute('preserveAspectRatio')) {
			clone.setAttribute('preserveAspectRatio', 'xMidYMid meet');
		}
		clone.setAttribute('role', 'img');
		if (captionText) clone.setAttribute('aria-label', captionText);

		lb.inner.innerHTML = '';
		lb.inner.appendChild(clone);
		lb.caption.textContent = captionText || '';
		lb.scale = 1; lb.tx = 0; lb.ty = 0;
		lbApplyTransform();
		lb.root.classList.add('open');
		lb.root.setAttribute('aria-hidden', 'false');
		document.body.classList.add('lb-open');

		/* Move focus into the dialog (close button is a sensible default). */
		const closeBtn = document.getElementById('lb-close');
		if (closeBtn) setTimeout(function() { closeBtn.focus(); }, 50);
	}

	function lbClose() {
		if (!lb.root) return;
		lb.root.classList.remove('open');
		lb.root.setAttribute('aria-hidden', 'true');
		document.body.classList.remove('lb-open');
		lb.inner.innerHTML = '';
		/* Restore focus to whatever opened the lightbox. */
		if (lb.lastFocused && typeof lb.lastFocused.focus === 'function') {
			try { lb.lastFocused.focus(); } catch (e) {}
		}
		lb.lastFocused = null;
	}

	function lbZoom(delta, centerX, centerY) {
		const prev = lb.scale;
		const next = Math.max(0.25, Math.min(8, prev * (delta > 0 ? 1.15 : 1 / 1.15)));
		if (next === prev) return;
		if (typeof centerX === 'number' && typeof centerY === 'number' && lb.stage) {
			const rect = lb.stage.getBoundingClientRect();
			const cx = centerX - rect.left - rect.width / 2;
			const cy = centerY - rect.top - rect.height / 2;
			const factor = next / prev;
			lb.tx = cx - (cx - lb.tx) * factor;
			lb.ty = cy - (cy - lb.ty) * factor;
		}
		lb.scale = next;
		lbApplyTransform();
	}

	function lbResetZoom() {
		lb.scale = 1; lb.tx = 0; lb.ty = 0;
		lbApplyTransform();
	}

	/* ---------- Focus trap (Tab cycles inside the dialog) ---------- */
	function getLightboxFocusables() {
		if (!lb.root) return [];
		const sel = 'button, [href], [tabindex]:not([tabindex="-1"])';
		return Array.prototype.slice.call(lb.root.querySelectorAll(sel))
			.filter(function(el) { return !el.disabled && el.offsetParent !== null; });
	}

	function trapFocusOnTab(e) {
		if (e.key !== 'Tab' || !lb.root.classList.contains('open')) return;
		const focusables = getLightboxFocusables();
		if (!focusables.length) return;
		const first = focusables[0];
		const last = focusables[focusables.length - 1];
		if (e.shiftKey && document.activeElement === first) {
			e.preventDefault();
			last.focus();
		} else if (!e.shiftKey && document.activeElement === last) {
			e.preventDefault();
			first.focus();
		}
	}

	function initLightbox() {
		lb.root    = document.getElementById('lightbox');
		lb.stage   = document.getElementById('lb-stage');
		lb.inner   = document.getElementById('lb-inner');
		lb.caption = document.getElementById('lb-caption');
		if (!lb.root) return;

		/* Make every diagram box keyboard-activatable. */
		const boxes = document.querySelectorAll('.diagram-box');
		boxes.forEach(function(box) {
			if (!box.hasAttribute('role')) box.setAttribute('role', 'button');
			if (!box.hasAttribute('tabindex')) box.setAttribute('tabindex', '0');
			if (!box.hasAttribute('aria-label')) {
				const cap = box.querySelector('.caption');
				box.setAttribute('aria-label',
					(cap ? cap.textContent.trim() : 'Diagram') + ' — click or press Enter to expand');
			}
			const open = function(e) {
				if (e.target.closest('a, button')) return;
				const svg = box.querySelector('svg');
				const cap = box.querySelector('.caption');
				if (!svg) return;
				lbOpen(svg, cap ? cap.textContent.trim() : '');
			};
			box.addEventListener('click', open);
			box.addEventListener('keydown', function(e) {
				if (e.key === 'Enter' || e.key === ' ') {
					e.preventDefault();
					open(e);
				}
			});
		});

		/* Close handlers */
		document.getElementById('lb-close').addEventListener('click', lbClose);
		lb.root.addEventListener('click', function(e) {
			if (e.target === lb.root || e.target === lb.stage) lbClose();
		});
		document.getElementById('lb-zoom-in').addEventListener('click', function(e) {
			e.stopPropagation(); lbZoom(1);
		});
		document.getElementById('lb-zoom-out').addEventListener('click', function(e) {
			e.stopPropagation(); lbZoom(-1);
		});
		document.getElementById('lb-zoom-reset').addEventListener('click', function(e) {
			e.stopPropagation(); lbResetZoom();
		});

		/* Wheel to zoom */
		lb.stage.addEventListener('wheel', function(e) {
			if (!lb.root.classList.contains('open')) return;
			e.preventDefault();
			lbZoom(e.deltaY < 0 ? 1 : -1, e.clientX, e.clientY);
		}, { passive: false });

		/* Drag to pan */
		lb.stage.addEventListener('mousedown', function(e) {
			if (e.button !== 0) return;
			lb.dragging = true;
			lb.dragStartX = e.clientX; lb.dragStartY = e.clientY;
			lb.dragOriginX = lb.tx; lb.dragOriginY = lb.ty;
			lb.stage.classList.add('dragging');
			e.preventDefault();
		});
		window.addEventListener('mousemove', function(e) {
			if (!lb.dragging) return;
			lb.tx = lb.dragOriginX + (e.clientX - lb.dragStartX);
			lb.ty = lb.dragOriginY + (e.clientY - lb.dragStartY);
			lbApplyTransform();
		});
		window.addEventListener('mouseup', function() {
			if (!lb.dragging) return;
			lb.dragging = false;
			lb.stage.classList.remove('dragging');
		});

		/* Keyboard handlers (focus trap + commands) */
		document.addEventListener('keydown', function(e) {
			if (!lb.root.classList.contains('open')) return;
			if (e.key === 'Escape') { lbClose(); return; }
			if (e.key === '+' || e.key === '=') { lbZoom(1); return; }
			if (e.key === '-' || e.key === '_') { lbZoom(-1); return; }
			if (e.key === '0') { lbResetZoom(); return; }
			trapFocusOnTab(e);
		});
	}

	/* ---------- Breadcrumb scrollspy ---------- */
	function initScrollspy() {
		const sections = document.querySelectorAll('section.sec[data-title]');
		const crumb = document.getElementById('breadcrumb-current');
		if (!crumb || !sections.length) return;
		if (!('IntersectionObserver' in window)) {
			/* Fallback: update on scroll (less efficient). */
			window.addEventListener('scroll', function() {
				const yMid = window.scrollY + 100;
				for (let i = 0; i < sections.length; i++) {
					const r = sections[i].getBoundingClientRect();
					const top = r.top + window.scrollY;
					if (top + sections[i].offsetHeight > yMid) {
						crumb.textContent = sections[i].getAttribute('data-title');
						return;
					}
				}
			}, { passive: true });
			return;
		}
		const visible = {};
		const obs = new IntersectionObserver(function(entries) {
			entries.forEach(function(e) {
				if (e.isIntersecting) visible[e.target.id] = true;
				else delete visible[e.target.id];
			});
			for (let i = 0; i < sections.length; i++) {
				if (visible[sections[i].id]) {
					crumb.textContent = sections[i].getAttribute('data-title');
					return;
				}
			}
		}, { rootMargin: '-80px 0px -60% 0px', threshold: 0 });
		sections.forEach(function(s) { obs.observe(s); });
	}

	/* ---------- Export Markdown ---------- */
	/* Reads #kb-md-export (base64 payload embedded by build-md-export.sh),
	   decodes it with a UTF-8-safe atob recipe, and downloads the result as a
	   .md file. Fails gracefully when the payload element is absent: the button
	   is disabled so it stays visible but non-interactive. */
	function initExportMarkdown() {
		const btn = document.getElementById('btn-export-md');
		if (!btn) return;
		const payloadEl = document.getElementById('kb-md-export');
		if (!payloadEl) {
			/* Payload not embedded (e.g. assemble.sh ran without build-md-export.sh). */
			btn.disabled = true;
			btn.title = 'Markdown export is not available (payload not embedded).';
			console.info('kb export: #kb-md-export element not found; Export as Markdown button disabled.');
			return;
		}
		btn.addEventListener('click', function() {
			const b64 = payloadEl.textContent;
			let md;
			try {
				md = new TextDecoder().decode(
					Uint8Array.from(atob(b64), function(c) { return c.charCodeAt(0); })
				);
			} catch (e) {
				console.warn('kb export: failed to decode Markdown payload.', e);
				return;
			}
			const blob = new Blob([md], { type: 'text/markdown' });
			const url = URL.createObjectURL(blob);
			const a = document.createElement('a');
			a.href = url;
			a.download = 'knowledge-base-export.md';
			document.body.appendChild(a);
			a.click();
			setTimeout(function() {
				document.body.removeChild(a);
				URL.revokeObjectURL(url);
			}, 100);
		});
	}

	/* ---------- Export PDF (print) ---------- */
	/* Opens all <details> (including details.accord) so the print-CSS can
	   capture their content, then calls window.print(). CSS alone cannot
	   reveal closed <details>; opening them in JS is required. Prior open
	   states are restored via the afterprint event. */
	function initExportPDF() {
		const btn = document.getElementById('btn-export-pdf');
		if (!btn) return;
		btn.addEventListener('click', function() {
			const allDetails = document.querySelectorAll('details');
			const priorOpen = [];
			for (let i = 0; i < allDetails.length; i++) {
				priorOpen.push(allDetails[i].open);
				allDetails[i].open = true;
			}
			const restoreDetails = function() {
				for (let i = 0; i < allDetails.length; i++) {
					allDetails[i].open = priorOpen[i];
				}
				window.removeEventListener('afterprint', restoreDetails);
			};
			window.addEventListener('afterprint', restoreDetails);
			window.print();
		});
	}

	/* ---------- Bootstrap ---------- */
	document.addEventListener('DOMContentLoaded', function() {
		setTimeout(initLightbox, 50);
		initScrollspy();
		initExportMarkdown();
		initExportPDF();

		const btn = document.getElementById('theme-toggle');
		if (btn) {
			btn.addEventListener('click', function() {
				const current = root.getAttribute('data-theme');
				setTheme(current === 'dark' ? 'light' : 'dark');
			});
		}

		/* Listen to OS-level theme changes if user hasn't explicitly chosen. */
		if (window.matchMedia) {
			const mq = window.matchMedia('(prefers-color-scheme: dark)');
			const handleChange = function(e) {
				let userChose = null;
				try { userChose = localStorage.getItem('aid-dashboard-theme'); } catch (_) {}
				if (!userChose) setTheme(e.matches ? 'dark' : 'light');
			};
			if (mq.addEventListener) mq.addEventListener('change', handleChange);
			else if (mq.addListener) mq.addListener(handleChange);
		}
	});
})();
