#!/usr/bin/env bash
# check-version-sync.sh — FR10 version-sync assertion.
#
# Verifies that all four version carriers agree on a single bare semver:
#   1. The VERSION file (repo source of truth)
#   2. packages/npm/package.json   ("version" field)
#   3. packages/pypi/pyproject.toml  ([project].version)
#   4. An optional expected version passed as --expect <VER> (e.g. from a git tag)
#
# When a manifest file is absent and its corresponding channel is not enabled
# (NPM_ENABLED / PYPI_ENABLED are not 'true'), that check is skipped with a notice.
# Once a manifest is present it is ALWAYS checked, regardless of enable flags.
#
# Usage:
#   bash check-version-sync.sh [--expect <version>] [--repo-root <path>]
#
#   --expect <version>   Assert all carriers match this bare semver (e.g. '0.7.5').
#                        If omitted, the carriers are asserted to be mutually consistent
#                        (all present carriers must equal the VERSION file value).
#   --repo-root <path>   Path to the repo root (default: directory of this script's
#                        grandparent, i.e. two levels above canonical/aid/scripts/release/).
#                        Useful in tests with temp fixtures.
#
# Exit codes:
#   0   all checks pass (or gracefully skipped)
#   1   one or more version carriers diverge
#   2   usage error
#
# Environment (optional overrides for tests):
#   NPM_ENABLED    set to 'true' to enforce npm check even if package.json absent
#   PYPI_ENABLED   set to 'true' to enforce PyPI check even if pyproject.toml absent
#
# Output:
#   On mismatch: a ::error:: annotation line naming the diverging carrier + values.
#   On skip:     a notice line.
#   On pass:     a confirmation line per carrier checked.

set -euo pipefail

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
EXPECT=""
REPO_ROOT=""

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --expect)
            [[ $# -ge 2 ]] || { echo "ERROR: --expect requires a value" >&2; exit 2; }
            EXPECT="$2"; shift 2 ;;
        --repo-root)
            [[ $# -ge 2 ]] || { echo "ERROR: --repo-root requires a value" >&2; exit 2; }
            REPO_ROOT="$2"; shift 2 ;;
        -h|--help)
            sed -n '2,45p' "$0" | sed 's/^# \{0,1\}//'
            exit 0 ;;
        *)
            echo "ERROR: check-version-sync.sh: unknown flag: $1" >&2; exit 2 ;;
    esac
done

# ---------------------------------------------------------------------------
# Resolve repo root
# ---------------------------------------------------------------------------
if [[ -z "$REPO_ROOT" ]]; then
    # Resolve the repo root by walking up from the script dir to the directory
    # that holds the VERSION file. This is robust to where under the tree the
    # script lives (a fixed `../../..` depth silently broke when the scripts moved
    # from canonical/scripts/ to canonical/aid/scripts/ — no ancestor between the
    # script and the repo root carries a VERSION file, so the walk-up is safe).
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    REPO_ROOT="$SCRIPT_DIR"
    while [[ "$REPO_ROOT" != "/" && ! -f "${REPO_ROOT}/VERSION" ]]; do
        REPO_ROOT="$(dirname "$REPO_ROOT")"
    done
fi

if [[ ! -f "${REPO_ROOT}/VERSION" ]]; then
    echo "ERROR: check-version-sync.sh: VERSION file not found under repo root: ${REPO_ROOT}" >&2
    exit 1
fi

# ---------------------------------------------------------------------------
# Read VERSION file
# ---------------------------------------------------------------------------
VERSION_FILE_VAL="$(tr -d '[:space:]' < "${REPO_ROOT}/VERSION")"

# ---------------------------------------------------------------------------
# Derive EXPECT: if not supplied, use the VERSION file value.
# ---------------------------------------------------------------------------
if [[ -z "$EXPECT" ]]; then
    EXPECT="${VERSION_FILE_VAL}"
fi

echo "check-version-sync: expected version = '${EXPECT}'"

# ---------------------------------------------------------------------------
# Pre-release detection (PyPI-only beta channel).
# A pre-release version (PEP 440 '2.2.3b1'/'2.2.3rc1'/'2.2.3a1', or the SemVer
# form '2.2.3-beta.1') is published to PyPI ONLY -- betas exist so specific
# testers can opt in via `pipx install "aid-installer==X.Y.Zb1"` (pip hides
# pre-releases from a plain install/upgrade, so stable users are untouched).
# npm ships NO pre-releases: packages/npm/package.json stays at the last stable
# and is therefore EXEMPT from the sync check when EXPECT is a pre-release (a
# beta bumps only VERSION + pyproject.toml + the tag). See the npm carrier below.
# ---------------------------------------------------------------------------
_is_prerelease() {
    local v="$1"
    local re='^[0-9]+\.[0-9]+\.[0-9]+([._-]?(alpha|beta|preview|pre|rc|a|b|c)[0-9]*|-[0-9A-Za-z.-]+)$'
    [[ "$v" =~ $re ]]
}
PRERELEASE=false
if _is_prerelease "${EXPECT}"; then
    PRERELEASE=true
    echo "check-version-sync: '${EXPECT}' is a PRE-RELEASE -> PyPI-only (npm carrier exempt)"
fi

# ---------------------------------------------------------------------------
# Assertion counter
# ---------------------------------------------------------------------------
fail=0
checked=0

# check_carrier <name> <actual>
# Emits a ::error:: annotation on mismatch (GitHub Actions compatible) and
# also a plain-text error so it's readable outside CI.
check_carrier() {
    local name="$1"
    local actual="$2"
    checked=$((checked + 1))
    if [[ "$actual" == "$EXPECT" ]]; then
        echo "  OK  : ${name} = '${actual}'"
    else
        echo "::error::${name} = '${actual}', expected '${EXPECT}' (from tag v${EXPECT})"
        echo "  FAIL: ${name} = '${actual}', expected '${EXPECT}'"
        fail=1
    fi
}

# _native_path <path>
# Render a path so it can be embedded in a CODE STRING handed to a Windows-NATIVE
# interpreter (node -p / python3 -c).
#
# Under MSYS/Git Bash, REPO_ROOT resolves to POSIX form (/c/Projects/...). MSYS
# translates paths that appear in *argv*, but NOT inside a quoted code string --
# so `node -p "require('/c/...')"` reaches a native node that cannot resolve the
# form. The read then fails, the substitution yields the EMPTY string, and both
# the npm and PyPI carriers are reported as diverging: a false FAIL of the very
# gate release.yml depends on. This is why the conversion has to be explicit.
#
# `cygpath -m` (mixed: C:/Projects/...) is used rather than `-w` on purpose: it
# keeps forward slashes, so the result needs no backslash re-escaping inside the
# quoted string, and node/python accept it directly.
#
# On Linux/macOS `cygpath` does not exist and no conversion is wanted, so the
# path passes through unchanged -- making this a no-op everywhere but Windows.
_native_path() {
    if command -v cygpath >/dev/null 2>&1; then
        cygpath -m "$1"
    else
        printf '%s' "$1"
    fi
}

# ---------------------------------------------------------------------------
# 1. VERSION file
# ---------------------------------------------------------------------------
check_carrier "VERSION" "${VERSION_FILE_VAL}"

# ---------------------------------------------------------------------------
# 2. packages/npm/package.json
# ---------------------------------------------------------------------------
NPM_JSON="${REPO_ROOT}/packages/npm/package.json"
NPM_ENABLED="${NPM_ENABLED:-false}"

if [[ "${PRERELEASE}" == "true" ]]; then
    # Pre-release (PyPI-only): npm ships no betas, so package.json legitimately
    # stays at the last stable and must NOT be required to equal EXPECT.
    echo "  SKIP: packages/npm/package.json exempt -- '${EXPECT}' is a pre-release (PyPI-only; npm stays on the last stable)"
elif [[ -f "${NPM_JSON}" ]]; then
    # File present: always check, regardless of NPM_ENABLED.
    # Both readers are native interpreters, so the path must be converted first
    # (see _native_path) -- a POSIX path here reads as empty on Windows.
    NPM_JSON_NATIVE="$(_native_path "${NPM_JSON}")"
    if command -v node >/dev/null 2>&1; then
        NPM_VER="$(node -p "require('${NPM_JSON_NATIVE}').version" 2>/dev/null)"
    elif command -v python3 >/dev/null 2>&1; then
        NPM_VER="$(python3 -c "import json; print(json.load(open('${NPM_JSON_NATIVE}'))['version'])")"
    else
        echo "  WARN: neither node nor python3 available to read package.json — skipping npm check"
        NPM_VER=""
    fi
    if [[ -n "${NPM_VER}" ]]; then
        check_carrier "packages/npm/package.json" "${NPM_VER}"
    fi
elif [[ "${NPM_ENABLED}" == "true" ]]; then
    echo "::error::packages/npm/package.json not found but NPM_ENABLED=true"
    echo "  FAIL: packages/npm/package.json missing (NPM_ENABLED=true)"
    fail=1
else
    echo "  SKIP: packages/npm/package.json not found and NPM_ENABLED != true"
fi

# ---------------------------------------------------------------------------
# 3. packages/pypi/pyproject.toml
# ---------------------------------------------------------------------------
PYPI_TOML="${REPO_ROOT}/packages/pypi/pyproject.toml"
PYPI_ENABLED="${PYPI_ENABLED:-false}"

if [[ -f "${PYPI_TOML}" ]]; then
    # File present: always check, regardless of PYPI_ENABLED.
    PYPI_VER=""
    # Native interpreter -- convert the path (see _native_path). The grep/sed
    # fallback below is pure bash and correctly keeps the POSIX path.
    PYPI_TOML_NATIVE="$(_native_path "${PYPI_TOML}")"
    if python3 -c "import tomllib" 2>/dev/null; then
        PYPI_VER="$(python3 -c "import tomllib; d=tomllib.load(open('${PYPI_TOML_NATIVE}','rb')); print(d['project']['version'])")"
    elif python3 -c "import tomli" 2>/dev/null; then
        PYPI_VER="$(python3 -c "import tomli; d=tomli.load(open('${PYPI_TOML_NATIVE}','rb')); print(d['project']['version'])")"
    else
        # Fallback: grep + sed (handles standard single-quoted and double-quoted values)
        PYPI_VER="$(grep -E '^version\s*=' "${PYPI_TOML}" | head -1 | sed 's/.*=\s*["'"'"']\(.*\)["'"'"'].*/\1/')"
    fi
    if [[ -n "${PYPI_VER}" ]]; then
        check_carrier "packages/pypi/pyproject.toml" "${PYPI_VER}"
    else
        echo "  WARN: could not extract version from pyproject.toml — skipping PyPI check"
    fi
elif [[ "${PYPI_ENABLED}" == "true" ]]; then
    echo "::error::packages/pypi/pyproject.toml not found but PYPI_ENABLED=true"
    echo "  FAIL: packages/pypi/pyproject.toml missing (PYPI_ENABLED=true)"
    fail=1
else
    echo "  SKIP: packages/pypi/pyproject.toml not found and PYPI_ENABLED != true"
fi

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
echo "check-version-sync: checked ${checked} carrier(s)."
if [[ "$fail" -ne 0 ]]; then
    echo "check-version-sync: VERSION SYNC FAILED — one or more carriers diverge from '${EXPECT}'."
    exit 1
fi
echo "check-version-sync: all carriers in sync at '${EXPECT}'."
exit 0
