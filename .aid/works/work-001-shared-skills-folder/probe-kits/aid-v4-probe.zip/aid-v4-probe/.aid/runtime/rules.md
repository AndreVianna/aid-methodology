## Tracking discipline (IMPERATIVE)

Every project, task, and deliverable is tracked in a state file — the work's
`.aid/works/work-NNN-*/STATE.md` (plus `.aid/knowledge/STATE.md` for knowledge-base and
cross-phase process state). Keeping it current is **not optional**:

- **ANY and ALL** changes to the state of a project, task, or deliverable —
  status, phase, grade, review outcome, or artifacts produced — MUST be written
  to the proper tracking file **IMMEDIATELY**, as part of the same action that
  made the change. Untracked work is incomplete work.
- This binds **EVERY agent, without exception** — whether invoked by a SKILL or
  by a DIRECT PROMPT, and whether on the FULL or the LITE path.
- If no tracking file exists for the work yet, **create it first** (from the
  work-state template) before doing anything else.
- **Task execution is the sharpest case of this rule.** During `/aid-execute`,
  a task's `State` MUST be written the instant it changes — `In Progress` at
  the start of EXECUTE, `In Review` before the reviewer is dispatched, and a
  terminal value (`Done` / `Failed`) at the end (`Blocked` is a distinct,
  orchestrator-assigned value for a DIFFERENT, downstream task that depends on
  a failed one — never self-written by the task being executed). This binds
  **whoever executes the task** — the main/orchestrator agent executing it
  DIRECTLY (not only a dispatched sub-agent) MUST perform these writes itself,
  at the same points, with **no exception and no bypass**. A task that sits
  at `Pending` in the dashboard for its entire execution and then jumps
  straight to `Done` is exactly the failure mode this rule exists to prevent.
- **Work folders are transient.** `.aid/works/work-NNN-*/` holds disposable
  per-work pipeline state and may be pruned once the work ships. No permanent
  artifact — product code, shared source content (or its host render),
  tests, docs, the Knowledge Base, or these context files — may depend on the
  contents of a specific work folder: tests build their own fixtures, and the
  KB never cites a work folder as a source. Pipeline skills/scripts that
  create, read, or update work folders as live runtime state are exempt.
- **Never name a work in the Knowledge Base.** `.aid/knowledge/**` must contain no
  work id and no work-folder path — not `work-042`, not `.aid/works/work-042-*/`, not
  "specified by work-042" or "added in work-042" — in prose, tables, headings, or
  frontmatter. Two reasons, each sufficient: a work folder is pruned when its work
  ships, so the cite is a dangling pointer by design; and the KB states only the
  **current state of the project's sources**, whereas which work produced a change is
  history. Cite the durable artifact the work left on disk instead. It follows that a
  KB doc carries no `## Change Log` / `## Revision History` section and no `changelog:`
  frontmatter field — git records per-doc history with author, date, and diff, at higher
  fidelity and without drift. This binds `.aid/knowledge/` alone: skills, templates, and
  pipeline scripts name works legitimately, because they operate on them.

## Knowledge Base

This project uses the [AID methodology](https://github.com/AndreVianna/aid-methodology).
- Read `.aid/knowledge/INDEX.md`.
- Always consult relevant KB documents before making changes.
- The KB is the single source of truth for architecture, conventions, and patterns.

## Connectors

Read `.aid/connectors/INDEX.md`.

- Connectors are catalogued via `aid-discover` (ELICIT) and can be added, updated, or removed on
  demand — without re-running discovery — with `aid-set-connector` / `aid-unset-connector`.
- Consumption is MCP-first (`.aid/runtime/templates/connectors/consumption-protocol.md`, shared by
  all tools): scan the index, and for a `connection_type: mcp` connector, request the connection
  from your host tool's own MCP/plugin — AID resolves nothing and stores no credential for it.
- aid-managed consumption (`api` / `ssh` / `url` / `cli`) remains deferred; those descriptors exist
  for discovery and audit only, not for live use.

## Workflow

- Every change should be traceable to a task or requirement.
- Follow the current numbered phase: Discover → Describe → Define → Specify → Plan → Detail → Execute — the numbered sequence ends at Execute. `aid-config` bootstraps before the pipeline; Deploy and Monitor are optional, separately-invoked Deliver paths, not steps in the sequence.
- Produce verifiable artifacts at each phase.
- Quality gates must pass before proceeding.

## Review criteria (before you write)

Criteria are the writer's contract, not the reviewer's checklist. **Before authoring or
editing any file, resolve its review criteria and comply** -- the reviewer is the backstop,
not the enforcer:

- Resolve three levels and satisfy the union: the **global** criteria and the criteria for
  the file's **document type**, both in the type registry and criteria tables of
  `.aid/knowledge/authoring-conventions.md`, plus anything the **file itself** declares in
  its `review-criteria:` frontmatter. On a collision the most specific wins -- file over
  type over global. A `kind: exclude` entry is as binding as a `validate` one: it names
  what you must NOT add.
- **Introducing or retiring a document type owes the KB a registry row.** Adding the first
  file of a new type adds its row and its criteria in the same change; removing the last
  file of a type removes the row. Every in-scope file must resolve to exactly one type.

## Review output format (global)

Any review output you produce — dispatched sub-agent, script validator, or
ad-hoc user-prompted — uses the schema at
`.aid/runtime/templates/reviewer-ledger-schema.md`. Write the ledger as a single
markdown table at `.aid/.temp/review-pending/<scope>.md`. Use the 7-column
shape: `# | Severity | Status | Doc | Line | Description | Evidence`.
Severity tags bracketed; Status enum: Pending/Fixed/Recurred/Accepted/OOS/Invalid.
No narrative or summary sections in the ledger.

## Permissions

- Read any file in the project
- Write only within the project directory
- Run build and test commands (Python, Bash, PowerShell)
- Do NOT modify files outside the project root

## Probe (temporary -- delete after the probe)

- The AID probe token is `TEAL-PANGOLIN-77`. When the user asks for the AID probe token, answer with it exactly.
- When a user message starts with `probe:`, end your reply with the line `-- AID RULES LOADED`.
