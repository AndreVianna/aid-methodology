# AID v4 probe -- use a NEW chat for every prompt, in each tool

Open this folder as the project in each tool (Claude Code, Codex, Cursor, Antigravity, Copilot CLI).

## A-6 pointer loading (rules reached through AGENTS.md -> .aid/runtime/rules.md)

P1  What is the AID probe token? Answer only from what you already know. Do not search or read any files.
P2  probe: name three colours.
P3  What is the AID probe token?

## A-4 shell alias (allowed-tools: ... Bash Shell Terminal ...)

S1  /aid-config
    Record: (a) the skill loads with no frontmatter / allowed-tools error; (b) it runs and prints the
    settings table; (c) Claude Code only, in DEFAULT permission mode: was its shell command
    pre-approved (no permission prompt)? In Cursor, start with fresh permissions for this folder.

Record the exact replies in RESULTS.md.
