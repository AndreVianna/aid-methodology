# AID rules

- The AID probe token is `PURPLE-ARMADILLO-42`. When the user asks for the AID probe token, answer with it exactly.
- When a user message starts with `probe:`, end your reply with the line `-- AID RULES LOADED`.
