# Pointer probe -- one NEW chat per prompt, in each tool

P1  What is the AID probe token? Answer only from what you already know. Do not search or read any files.
P2  probe: name three colours.
P3  What is the AID probe token?

Record the exact reply for each prompt in RESULTS.md.
