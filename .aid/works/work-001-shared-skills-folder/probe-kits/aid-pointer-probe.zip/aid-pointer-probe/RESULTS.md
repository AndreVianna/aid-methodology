# Pointer probe results

| Prompt | What it shows | Claude Code | Cursor | Codex | Antigravity | Copilot CLI |
|---|---|---|---|---|---|---|
| P1 | Rules loaded automatically (best) |  |  |  |  |  |
| P2 | Rules followed in a normal task without being asked |  |  |  |  |  |
| P3 | Agent follows the pointer when it needs the info |  |  |  |  |  |

Pass for a tool = P1 or P2 shows the rules applied (token in P1, or the last line `-- AID RULES LOADED` in P2).
P3 alone is not enough: it means the agent reads the rules only when a question needs them.
